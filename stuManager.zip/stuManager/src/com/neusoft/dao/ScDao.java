package com.neusoft.dao;

import java.util.List;

import com.neusoft.bean.Sc;

public interface ScDao {
	
	
	List<Sc> getById(int sid);
	
	int add(Sc s);
	
	int delete(Sc s);
}
