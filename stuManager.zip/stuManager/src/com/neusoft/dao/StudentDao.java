package com.neusoft.dao;

import java.util.List;

import com.neusoft.bean.Student;

public interface StudentDao {
	
	int PAGESIZE=1;
	
	List<Student> getAll();
	
	Student getById(int sid);
	
	Student getById2(int sid);
	
	Student getSid(String uname);
	
	Student getSid2(int sid);
	
	Student getUnamePwd(int sid);
	
	Student getByUname(String uname);
		
	List<Student> getSex();
	
	List<Student> getByLike(String sname);
		
	List<Student> getByLike2(String sname);
	
	List<Student> getByName(String sname);
	
	int login(Student s);
	
	int add(Student s);
	
	int delete(int sid);

	int update(Student s);
	
	int updateUnamePwd(Student s);
	
	int unametest(String uname);
	
	List<Student> getByPage(int currentpage);
	
	int countStu();
	
	
}
