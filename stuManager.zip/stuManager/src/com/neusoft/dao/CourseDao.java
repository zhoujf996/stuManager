package com.neusoft.dao;

import java.util.List;

import com.neusoft.bean.Course;

public interface CourseDao {
	
	int PAGESIZE=1;

	List<Course> getByPage(int currentpage);
	
	List<Course> getAll();
	
	List<Course> getAllCimg();
	
	int add(Course c);
	
	int countCor();
	
	Course getById(int coid);
	
	int update(Course c);
	
	int delete(int coid);
	
	List<Course> getByLike(String coname);
	
}
