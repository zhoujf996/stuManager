package com.neusoft.dao;

import java.util.List;

import com.neusoft.bean.Classes;

public interface ClassesDao {
	int add(Classes c);
	
	int update(Classes c);
	
	List<Classes> getAll();
	
	List<Classes> getCname();
}
