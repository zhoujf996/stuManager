package com.neusoft.dao;

import java.util.List;

import com.neusoft.bean.Score;

public interface ScoreDao {
	
	int PAGESIZE=1;
	
	List<Score> getAllById(int sid);
	
	List<Score> getBySid(int sid);
	
	List<Score> getBySid2(int sid);
	
	Score getBySidCoid(int sid,int coid);
	
	List<Score> getAllByUname(String uname);
	
	int countScore();
	
	List<Score> getByPage(int currentPage);
	
	int update(Score s);
	
	int delete(int sid,int coid);
	
	int add(Score s);
}
