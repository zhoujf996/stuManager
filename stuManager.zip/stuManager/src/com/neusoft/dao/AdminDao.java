package com.neusoft.dao;

import com.neusoft.bean.Admin;

public interface AdminDao {
	 int update(Admin a);
	 
	 int login(Admin a);
	 
	 int unametest(Admin a);
	 
	 Admin getByUname(String uname);

	 Admin getById(int aid);
}
