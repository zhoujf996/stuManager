package com.neusoft.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Score;
import com.neusoft.dao.ScoreDao;
import com.neusoft.impl.ScoreDaoImpl;



@WebServlet("/getScoreByIdServlet")
public class getScoreByIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       


    public getScoreByIdServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int sid=Integer.valueOf(request.getParameter("sid"));
		ScoreDao sd=new ScoreDaoImpl();
		List<Score> slist=new ArrayList<Score>();
		slist=sd.getBySid2(sid);
		request.getSession().setAttribute("slist",slist);
		response.sendRedirect("getScoreById.jsp");
	}

}
