package com.neusoft.servlet;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import com.neusoft.bean.Score;
import com.neusoft.bean.Student;
import com.neusoft.dao.ScoreDao;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.ScoreDaoImpl;
import com.neusoft.impl.StudentDaoImpl;


@WebServlet("/SelectSc")
public class SelectSc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SelectSc() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		List<Score> slist=new ArrayList<Score>();
		int sid=Integer.valueOf(request.getParameter("sid"));
		StudentDao std=new StudentDaoImpl();
		Student s=new Student();
		ScoreDao sd=new ScoreDaoImpl();
		slist=sd.getBySid(sid);
		s=std.getSid2(sid);
		request.getSession().setAttribute("slist", slist);
		request.getSession().setAttribute("s", s);
		response.sendRedirect("selectsc.jsp");
		
	}

}
