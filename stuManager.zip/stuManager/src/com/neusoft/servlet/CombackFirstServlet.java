package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Student;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.StudentDaoImpl;


@WebServlet("/CombackFirstServlet")
public class CombackFirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CombackFirstServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int sid=Integer.valueOf(request.getParameter("sid"));
		StudentDao sd=new StudentDaoImpl();
		Student stu=new Student();
		stu=sd.getById(sid);
		request.getSession().setAttribute("stu", stu);
		response.sendRedirect("indexstudent.jsp");
	}

}
