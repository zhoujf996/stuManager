package com.neusoft.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Student;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.StudentDaoImpl;


@WebServlet("/getStuByLikeServlet")
public class getStuByLikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	
    public getStuByLikeServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String sname=request.getParameter("sname");
		StudentDao st=new StudentDaoImpl();
		List<Student> slist=new ArrayList<Student>();
		slist=st.getByLike2(sname);
		request.getSession().setAttribute("slist", slist);
		response.sendRedirect("getStudentBylike.jsp");
	}
	

}
