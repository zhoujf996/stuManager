package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Admin;
import com.neusoft.dao.AdminDao;
import com.neusoft.impl.AdminDaoImpl;


@WebServlet("/SelectAdminServlet")
public class SelectAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public SelectAdminServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int aid=Integer.valueOf(request.getParameter("aid"));
		AdminDao ad=new AdminDaoImpl();
		Admin a=new Admin();
		a=ad.getById(aid);
		request.getSession().setAttribute("a",a);
		response.sendRedirect("adminupdate.jsp");
	}

}
