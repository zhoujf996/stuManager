package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.PageBean;
import com.neusoft.bean.Score;
import com.neusoft.bean.Student;
import com.neusoft.dao.ScoreDao;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.ScoreDaoImpl;
import com.neusoft.impl.StudentDaoImpl;
import com.neusoft.service.PageService;


@WebServlet("/ChoiceCourseServlet")
public class ChoiceCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ChoiceCourseServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int sid=Integer.valueOf(request.getParameter("sid"));
		int coid=Integer.valueOf(request.getParameter("coid"));
		Score sc=new Score(sid,coid);
		ScoreDao sd=new ScoreDaoImpl();
		if(sd.add(sc)>0){
			
			StudentDao st=new StudentDaoImpl();
			Student s=new Student();
			s=st.getSid2(sid);
			PageService ps=new PageService();
			PageBean p=new PageBean();
			p=ps.getByPage(0);				
			request.getSession().setAttribute("p", p);
			request.getSession().setAttribute("s", s);
			response.sendRedirect("selectcourse.jsp");
		}else{
			response.sendRedirect("fail.jsp");
		}
		
	}

}
