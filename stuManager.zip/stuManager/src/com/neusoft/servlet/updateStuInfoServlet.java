package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Student;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.StudentDaoImpl;


@WebServlet("/updateStuInfoServlet")
public class updateStuInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public updateStuInfoServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		int sid=Integer.valueOf( request.getParameter("sid"));
		String sname=request.getParameter("sname");
		String sex=request.getParameter("sex");
		String address=request.getParameter("address");
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		String simg=request.getParameter("simg");
		int cid=Integer.valueOf(request.getParameter("cid"));
		
		StudentDao st=new StudentDaoImpl();
		Student s=new Student(sid,sname,sex,address,uname,pwd,simg,cid);
		if(st.update(s)>0){
			request.getRequestDispatcher("/GetAllStudent").forward(request, response);

		}else{
			response.sendRedirect("fail.jsp");
		}
	
		

	}

}
