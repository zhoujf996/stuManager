package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Score;
import com.neusoft.dao.ScoreDao;
import com.neusoft.impl.ScoreDaoImpl;


@WebServlet("/updateStuScoreServlet")
public class updateStuScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public updateStuScoreServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int sid=Integer.valueOf(request.getParameter("sid"));
		int coid=Integer.valueOf(request.getParameter("coid"));
		int score=Integer.valueOf(request.getParameter("score"));

		ScoreDao sd=new ScoreDaoImpl();
		Score s=new Score(sid,coid,score);
		if(sd.update(s)>0){
			request.getRequestDispatcher("/GetAllScore").forward(request, response);
		}else{
			response.sendRedirect("fail.jsp");
		}
	}

}