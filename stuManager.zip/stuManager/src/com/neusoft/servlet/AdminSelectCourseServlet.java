package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.PageBean;
import com.neusoft.service.PageService;


@WebServlet("/AdminSelectCourseServlet")
public class AdminSelectCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AdminSelectCourseServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		PageService ps=new PageService();
		PageBean p=new PageBean();
		p=ps.getByPage(0);				
		request.getSession().setAttribute("p", p);
		response.sendRedirect("coursemanage.jsp");
	}

}
