package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Student;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.StudentDaoImpl;


@WebServlet("/LoginStudentServlet")
public class LoginStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginStudentServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
			String uname=request.getParameter("uname");
			String pwd=request.getParameter("pwd");
			StudentDao st=new StudentDaoImpl();
			
			Student s=new Student(uname,pwd);
			if(st.login(s)>0){
				st.unametest(uname);
				response.getWriter().println(1);
				Student stu=new Student();
				stu=st.getByUname(uname);
				request.getSession().setAttribute("stu", stu);
				response.sendRedirect("indexstudent.jsp");
			}else{
				response.sendRedirect("fail.jsp");

			}
	}

}
