package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Score;
import com.neusoft.dao.ScoreDao;
import com.neusoft.impl.ScoreDaoImpl;


@WebServlet("/ScoreUpdateServlet")
public class ScoreUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ScoreUpdateServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int sid=Integer.valueOf(request.getParameter("sid"));
		int coid=Integer.valueOf(request.getParameter("coid"));
		
		ScoreDao sd=new ScoreDaoImpl();
		Score s=sd.getBySidCoid(sid,coid);
		request.getSession().setAttribute("s", s);
		response.sendRedirect("scoreupdate.jsp");
	}

}
