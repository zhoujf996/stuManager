package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Admin;
import com.neusoft.dao.AdminDao;
import com.neusoft.impl.AdminDaoImpl;


@WebServlet("/LoginAdminServlet")
public class LoginAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginAdminServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		Admin a=new Admin(uname,pwd);
		AdminDao ad=new AdminDaoImpl();
		if(ad.login(a)>0){
			Admin admin=new Admin();
			admin=ad.getByUname(uname);
			request.getSession().setAttribute("a", admin);
			response.sendRedirect("indexadmin.jsp");
		}else{
			response.sendRedirect("fail.jsp");
		}
	}

}
