package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.PageBean;
import com.neusoft.service.PageService;


@WebServlet("/PageServlet")
public class PageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public PageServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int current=Integer.valueOf(request.getParameter("current"));
		PageService ps=new PageService();
		PageBean p=new PageBean();
		p=ps.getByPage(current);
		request.getSession().setAttribute("p", p);
		response.sendRedirect("selectcourse.jsp");
	}

}
