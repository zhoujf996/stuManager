package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Course;
import com.neusoft.dao.CourseDao;
import com.neusoft.impl.CourseDaoImpl;


@WebServlet("/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AddCourseServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String coname=request.getParameter("coname");
		String cimg=request.getParameter("cimg");
		String teacher=request.getParameter("teacher");
	

		CourseDao cd=new CourseDaoImpl();
		Course c=new Course(coname,cimg,teacher);
		if(cd.add(c)>0){
			request.getRequestDispatcher("/AdminSelectCourse").forward(request, response);
		}else{
			response.sendRedirect("fail.jsp");
		}
	}

}
