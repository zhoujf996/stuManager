package com.neusoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neusoft.bean.Admin;
import com.neusoft.dao.AdminDao;
import com.neusoft.impl.AdminDaoImpl;


@WebServlet("/adminUpdate")
public class adminUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public adminUpdate() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int aid=Integer.valueOf(request.getParameter("aid"));
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		AdminDao ad=new AdminDaoImpl();
		Admin admin=new Admin(aid,uname,pwd);
		if(ad.update(admin)>0){
			Admin a=new Admin();
			a=ad.getById(aid);
			request.getSession().setAttribute("a", a);
			response.sendRedirect("indexadmin.jsp");
		}else{
			response.sendRedirect("fail.jsp");

		}
		
	}

}
