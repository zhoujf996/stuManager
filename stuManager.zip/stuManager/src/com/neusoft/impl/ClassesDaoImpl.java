package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Classes;
import com.neusoft.dao.BaseDao;
import com.neusoft.dao.ClassesDao;

public class ClassesDaoImpl extends BaseDao implements ClassesDao{
	  BaseDao bd = new BaseDao();

	@Override
	public int add(Classes c) {
		int re=-1;
		String sql="INSERT INTO classes(cname,college) VALUES(?,?)";
		re=bd.executeUpdate(sql, c.getCname(),c.getCollege());
		return re;
	}

	
	
	@Override
	public int update(Classes c) {
		int re=-1;
		String sql="UPDATE classes SET cname=?,college=? WHERE cid=?";
		re=bd.executeUpdate(sql, c.getCname(),c.getCollege(),c.getCid());
		return re;
	}
	
	


	@Override
	public List<Classes> getAll() {
		List<Classes> clist=new ArrayList<Classes>();
		String sql="SELECT * FROM classes";
		ResultSet rs=bd.executeQuery(sql);
		Classes c=new Classes();
		try {
			while(rs.next()){
				c=new Classes(rs.getInt(1),rs.getString(2),rs.getString(3));
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}



	@Override
	public List<Classes> getCname() {
		List<Classes> clist=new ArrayList<Classes>();
		String sql="SELECT  c.`cid` ,c.`cname` FROM classes c";
		ResultSet rs=bd.executeQuery(sql);
		Classes c=null;
		try {
			while(rs.next()){
				c=new Classes(rs.getInt(1),rs.getString(2));
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}
	
	public static void main(String[] args) {
		ClassesDao cd=new ClassesDaoImpl();
		List<Classes> clist=new ArrayList<Classes>();
		clist=cd.getCname();
		for(Classes cs:clist){
			System.out.println(cs.getCid()+cs.getCname());
		}
	}


}
