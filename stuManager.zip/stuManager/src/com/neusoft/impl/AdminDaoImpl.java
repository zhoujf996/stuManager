package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.neusoft.bean.Admin;
import com.neusoft.dao.AdminDao;
import com.neusoft.dao.BaseDao;

public class AdminDaoImpl extends BaseDao implements AdminDao{
	  BaseDao bd = new BaseDao();
	  
	@Override
	public int update(Admin a) {
		int re=-1;
		String sql="UPDATE admin SET uname=?, pwd=? WHERE aid=?";
		re=bd.executeUpdate(sql, a.getUname(),a.getPwd(),a.getAid());
		return re;
	}
	
	@Override
	public int login(Admin a) {
		int re=-1;
		String sql="SELECT COUNT(uname) FROM admin  a "+
		"WHERE a.`uname`=? AND a.`pwd`=? ";
		ResultSet rs=bd.executeQuery(sql, a.getUname(),a.getPwd());
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}
	
	

	@Override
	public int unametest(Admin a) {
		int re=-1;
		String sql=" SELECT COUNT(*) FROM admin  WHERE uname=? ";
		ResultSet rs=bd.executeQuery(sql, a.getUname());
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}

	

	@Override
	public Admin getByUname(String uname) {
		String sql="SELECT  a.`aid`,a.`uname`,a.`pwd` FROM admin a WHERE a.`uname`=?";
		ResultSet rs=bd.executeQuery(sql, uname);
		Admin a=null;
		try {
			if(rs.next()){
				 a=new Admin(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}
	

	@Override
	public Admin getById(int aid) {
		String sql="SELECT  a.`aid`  FROM  admin a WHERE  a.`aid`=? ";
		ResultSet rs=bd.executeQuery(sql, aid);
		Admin a=null;
		try {
			if(rs.next()){
				a=new Admin(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}

	public static void main(String[] args) {
		AdminDao ad=new AdminDaoImpl();
		Admin a=new Admin();
		a=ad.getById(1);
		System.out.println(a.getAid());
	}

	 	
}
