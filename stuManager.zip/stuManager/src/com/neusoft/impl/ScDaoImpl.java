package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Course;
import com.neusoft.bean.Sc;
import com.neusoft.bean.Student;
import com.neusoft.dao.BaseDao;
import com.neusoft.dao.ScDao;

public class ScDaoImpl extends BaseDao implements ScDao {
	BaseDao bd=new BaseDao();

	@Override
	public List<Sc> getById(int sid) {
		List<Sc> slist=new ArrayList<Sc>();
		Sc s=null;
		Student st=null;
		Course c=null;
		
		String sql="SELECT s1.`sid`, s1.`sname` , c.`coname`, c.`cimg` ,c.`teacher` FROM student s1 , sc s2, course c "
					+"WHERE s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` AND s1.`sid`=? ";

		 ResultSet rs=bd.executeQuery(sql, sid);
		 
		 try {
			while(rs.next()){
				 st=new Student(rs.getInt(1),rs.getString(2));
				 c=new Course(rs.getString(3),rs.getString(4),rs.getString(5));
				 s=new Sc(st,c);
				 slist.add(s);
			 }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return slist;
	}
	
	

	@Override
	public int add(Sc s) {
		int re=-1;
		String sql="INSERT INTO sc(sid,coid) VALUES(?,?)";
		re=bd.executeUpdate(sql, s.getSid(),s.getCoid());
		return re;
	}
	
	
	@Override
	public int delete(Sc s) {
		int re=-1;
		String sql="DELETE FROM sc WHERE sid=? AND coid=? ";
		re=bd.executeUpdate(sql, s.getSid(),s.getCoid());
		return re;
	}

	
	public static void main(String[] args) {
		List<Sc> slist=new ArrayList<Sc>();
		ScDao sc=new ScDaoImpl();
		slist=sc.getById(1);
		for(Sc s:slist){
			System.out.println(s.getStudent().getSid()+s.getStudent().getSname()+s.getCourse().getConame()+s.getCourse().getTeacher()+s.getCourse().getCimg());
		}
	}

}
