package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Course;
import com.neusoft.dao.BaseDao;
import com.neusoft.dao.CourseDao;

public class CourseDaoImpl extends BaseDao implements CourseDao{
	BaseDao bd=new BaseDao();
	
	@Override
	public List<Course> getAll() {
		List<Course> clist=new ArrayList<Course>();
		Course c=null;
		String sql="SELECT  c.`coid`,c.`coname`,c.`cimg`,c.`teacher`  FROM course  c";
		ResultSet rs=bd.executeQuery(sql);
		try {
			while(rs.next()){
				c=new Course(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}
	
	
	@Override
	public int add(Course c) {
		int re=-1;
		String sql="INSERT INTO course(coname,cimg,teacher) VALUES(?,?,?)";
		re=bd.executeUpdate(sql, c.getConame(),c.getCimg(),c.getTeacher());
		return re;
	}
	


	@Override
	public int countCor() {
		int re=-1;
		String sql="SELECT COUNT(*) FROM course";
		ResultSet rs=bd.executeQuery(sql);
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}
	
	


	@Override
	public List<Course> getByPage(int currentpage) {
		List<Course> clist=new ArrayList<Course>();
		String sql="SELECT  c.`cimg` ,c.`coid`, c.`coname`,c.`teacher`  FROM course c  LIMIT ?,?";
		ResultSet rs=bd.executeQuery(sql, currentpage, PAGESIZE);
		try {
			while(rs.next()){
				Course c=new Course();
				c.setCimg(rs.getString(1));
				c.setCoid(rs.getInt(2));
				c.setConame(rs.getString(3));
				c.setTeacher(rs.getString(4));
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}
	

	public static void main(String[] args) {
		List<Course> clist=new ArrayList<Course>();
		CourseDao cd=new CourseDaoImpl();
		clist=cd.getByPage(0);
		for(Course cl:clist){
			System.out.println(cl.getCimg());
		}
	}


	@Override
	public Course getById(int coid) {
		String sql="SELECT  c.`coid`,c.`coname`,c.`cimg`,c.`teacher` FROM course c WHERE c.`coid`=?";
		ResultSet rs=bd.executeQuery(sql, coid);
		Course c=null;
		try {
			if(rs.next()){
				c=new Course(rs.getInt(1),rs.getString(2),
						rs.getString(3),rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}


	@Override
	public int update(Course c) {
		int re=-1;
		String sql="UPDATE  course c  SET  c.`coname`=? ,c.`cimg`=? ,c.`teacher`=?  WHERE c.`coid`=?";
		re=bd.executeUpdate(sql, c.getConame(),c.getCimg(),c.getTeacher(),c.getCoid());
		return re;
	}


	@Override
	public int delete(int coid) {
		int re=-1;
		String sql="DELETE FROM course c WHERE c.`coid`=?";
		re=bd.executeUpdate(sql, coid);
		return re;
	}


	@Override
	public List<Course> getAllCimg() {
		List<Course> clist=new ArrayList<Course>();
		Course c=null;
		String sql="SELECT  c.`cimg`  FROM course c";
		ResultSet rs=bd.executeQuery(sql);
		try {
			while(rs.next()){
				c=new Course();
				c.setCimg(rs.getString(1));
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}


	@Override
	public List<Course> getByLike(String coname) {
		List<Course> clist=null;
		Course c=null;
		String sql="SELECT c.`coid` ,c.`coname`, c.`cimg`, c.`teacher`  FROM course c WHERE c.`coname` LIKE ?";
		ResultSet rs=bd.executeQuery(sql, "%"+coname+"%");
		try {
			while(rs.next()){
				c=new Course(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				clist=new ArrayList<Course>();
				clist.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clist;
	}
	

	
}



