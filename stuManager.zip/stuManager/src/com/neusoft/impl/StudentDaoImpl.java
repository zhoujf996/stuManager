package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Classes;
import com.neusoft.bean.Student;
import com.neusoft.dao.BaseDao;
import com.neusoft.dao.StudentDao;

public class StudentDaoImpl extends BaseDao implements StudentDao{
	BaseDao bd=new BaseDao();
	
	
	@Override
	public List<Student> getAll() {
		List<Student> slist=new ArrayList<Student>();
		String sql="SELECT sid , sname , sex ,address , cname ,college FROM student s, classes c WHERE s.`cid`=c.`cid`";
		ResultSet rs=bd.executeQuery(sql);
		try {
			while(rs.next()){
				Student s=new Student();
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSex(rs.getString(3));
				s.setAddress(rs.getString(4));
				Classes c=new Classes(rs.getString(5),rs.getString(6));
				s.setClasses(c);
				slist.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}
	
	
	
	@Override
	public Student getById(int sid) {
		String sql="SELECT sid , sname , sex ,address ,uname, pwd, simg, cname ,college FROM"+
				" student s, classes c WHERE s.`cid`=c.`cid` AND sid=?";
		ResultSet rs=bd.executeQuery(sql, sid);
		Student s=new Student();
		try {
			if(rs.next()){
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSex(rs.getString(3));
				s.setAddress(rs.getString(4));
				s.setUname(rs.getString(5));
				s.setPwd(rs.getString(6));
				s.setSimg(rs.getString(7));
				Classes c=new Classes(rs.getString(8),rs.getString(9));
				s.setClasses(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}
	
	@Override
	public Student getByUname(String uname) {
		String sql="SELECT sid , sname , sex ,address ,uname, pwd, simg, cname ,college FROM"+
					" student s, classes c WHERE s.`cid`=c.`cid` AND uname=?";
		ResultSet rs=bd.executeQuery(sql, uname);
		Student s=new Student();
		try {
			if(rs.next()){
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSex(rs.getString(3));
				s.setAddress(rs.getString(4));
				s.setUname(rs.getString(5));
				s.setPwd(rs.getString(6));
				s.setSimg(rs.getString(7));
				Classes c=new Classes(rs.getString(8),rs.getString(9));
				s.setClasses(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}


	@Override
	public Student getSid(String uname) {
		String sql="SELECT  s.`sid`  FROM  student  s  WHERE  s.`uname`=? ";
		ResultSet rs=bd.executeQuery(sql, uname);
		Student s=null;
		try {
			if(rs.next()){
				s=new Student(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public Student getSid2(int sid) {
		String sql="SELECT  s.sid  FROM student s WHERE  s.sid=? ";
		ResultSet rs=bd.executeQuery(sql, sid);
		Student s=null;
		try {
			if(rs.next()){
				s=new Student(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}



	
	
	@Override
	public List<Student> getByLike(String sname){
		  List<Student> slist = new ArrayList<Student>();
		  String sql="SELECT  sid , sname, sex, address , cname , college  FROM  student s ,classes c WHERE s.cid=c.cid  AND sname  LIKE ? ";
		  ResultSet rs = bd.executeQuery(sql, "%" + sname + "%");
			try {
				while(rs.next()){
					Student s=new Student();
					s.setSid(rs.getInt(1));
					s.setSname(rs.getString(2));
					s.setSex(rs.getString(3));
					s.setAddress(rs.getString(4));
					Classes c=new Classes(rs.getString(5),rs.getString(6));
					s.setClasses(c);
					slist.add(s);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return slist;
	}
	

	@Override
	public List<Student> getByLike2(String sname) {
		  List<Student> slist = new ArrayList<Student>();
		  String sql="SELECT simg , sid , sname , sex , address ,  cname , college  FROM  student s ,classes c "+
				  		"WHERE s.cid=c.cid  AND sname  LIKE ?";
		  ResultSet rs = bd.executeQuery(sql, "%" + sname + "%");
			try {
				while(rs.next()){
					Student s=new Student();
					s.setSimg(rs.getString(1));
					s.setSid(rs.getInt(2));
					s.setSname(rs.getString(3));
					s.setSex(rs.getString(4));
					s.setAddress(rs.getString(5));
					Classes c=new Classes(rs.getString(6),rs.getString(7));
					s.setClasses(c);
					slist.add(s);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return slist;
		}
	

	
	@Override
	public List<Student> getByName(String sname) {
		 List<Student> slist = new ArrayList<Student>();
		 String sql="SELECT   sid , sname, sex, address, cname ,college  FROM  student s ,classes c WHERE s.cid=c.cid  AND sname= ? ";
		 ResultSet rs = bd.executeQuery(sql, sname);
			try {
				while(rs.next()){
					Student s=new Student();
					s.setSid(rs.getInt(1));
					s.setSname(rs.getString(2));
					s.setSex(rs.getString(3));
					s.setAddress(rs.getString(4));
					Classes c=new Classes(rs.getString(5),rs.getString(6));
					s.setClasses(c);
					slist.add(s);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return slist;
	}
	
	
	
	@Override
	public int login(Student s) {
		int re=-1;
		String sql="SELECT COUNT(uname) FROM student s WHERE  uname=?  AND pwd= ?";
		ResultSet rs=bd.executeQuery(sql, s.getUname(),s.getPwd());
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}


	@Override
	public int add(Student s) {
		int re=-1;
		String sql="INSERT INTO student(sname,sex,address,uname,pwd,simg,cid) VALUES(?,?,?,?,?,?,?)";
		re=bd.executeUpdate(sql, s.getSname(),s.getSex(),s.getAddress(),s.getUname(),s.getPwd(),s.getSimg(),s.getCid());
		return re;
	}
	

	@Override
	public int delete(int sid) {
		int re=-1;
		String sql=" DELETE FROM student WHERE sid= ?";
		re=bd.executeUpdate(sql, sid);
		return re;
	}

	
	@Override
	public int update(Student s) {
		int re=-1;
		String sql="UPDATE student SET sname=?,sex=?,address=? ,uname=?,pwd=? ,cid=? WHERE sid=?";
		re=bd.executeUpdate(sql, s.getSname(),s.getSex(),s.getAddress(),s.getUname(),s.getPwd(),s.getCid(),s.getSid());
		return re;
	}
	
	@Override
	public int updateUnamePwd(Student s) {
		int re=-1;
		String sql="UPDATE student s  SET  s.`uname`= ?, s.`pwd`=?  WHERE  s.`sid`=? ";
		re=bd.executeUpdate(sql,s.getUname(),s.getPwd(),s.getSid());
		return re;
	}


	@Override
	public int unametest(String uname) {
		int re=-1;
		String sql="SELECT COUNT(*) FROM student  WHERE uname=?";
		ResultSet rs=bd.executeQuery(sql, uname);
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}
	
	@Override
	public Student getUnamePwd(int sid) {
		Student s=null;
		String sql="SELECT  s.`sid`, s.`uname`,s.`pwd`  FROM student s WHERE s.`sid`=?";
		ResultSet rs=bd.executeQuery(sql, sid);
		try {
			if(rs.next()){
				s=new Student(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

	

	@Override
	public List<Student> getByPage(int currentpage) {
		List<Student> slist=new ArrayList<Student>();
		String sql="SELECT  s.`sid` ,s.`sname`,s.`sex`,s.`address` , s.`simg`,c.`cname`,c.`college`"
					+"FROM student  s ,classes c WHERE s.`cid`=c.`cid` LIMIT ?,?";
		ResultSet rs=bd.executeQuery(sql,currentpage,PAGESIZE);
		try {
			while(rs.next()){
				Student s=new Student();
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSex(rs.getString(3));
				s.setAddress(rs.getString(4));
				s.setSimg(rs.getString(5));
				Classes c=new Classes(rs.getString(6),rs.getString(7));
				s.setClasses(c);
				slist.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}
	
	
	@Override
	public int countStu() {
		int re=-1;
		String sql="SELECT COUNT(*) FROM student s";
		ResultSet rs=bd.executeQuery(sql);
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}

	


	@Override
	public Student getById2(int sid) {
		String sql="SELECT s.`sid`,s.`sname`,s.`sex`,s.`address`  ,s.`uname`,s.`pwd`,s.`simg` "
						+"FROM student s  WHERE s.`sid`= ? ";
		ResultSet rs=bd.executeQuery(sql, sid);
		Student s=new Student();
		try {
			if(rs.next()){
				s.setSid(rs.getInt(1));
				s.setSname(rs.getString(2));
				s.setSex(rs.getString(3));
				s.setAddress(rs.getString(4));
				s.setUname(rs.getString(5));
				s.setPwd(rs.getString(6));
				s.setSimg(rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

	public static void main(String[] args) {
		List<Student> slist=new ArrayList<Student>();
		StudentDao sd=new StudentDaoImpl();
		Student s=new Student();
		s=sd.getById2(1);
		System.out.println(s.getSid());
	}


	@Override
	public List<Student> getSex() {
		List<Student> slist=new ArrayList<Student>();
		String sql="SELECT  DISTINCT   s.`sex`   FROM student s";
		ResultSet rs=bd.executeQuery(sql);
		Student s=null;
		try {
			while(rs.next()){
				s=new Student();
				s.setSex(rs.getString(1));
				slist.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}
	
	



}
