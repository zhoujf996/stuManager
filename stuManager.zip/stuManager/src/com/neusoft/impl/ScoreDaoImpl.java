package com.neusoft.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Course;
import com.neusoft.bean.Score;
import com.neusoft.bean.Student;
import com.neusoft.dao.BaseDao;
import com.neusoft.dao.ScoreDao;

public class ScoreDaoImpl extends BaseDao implements ScoreDao {
	BaseDao bd=new BaseDao();
	@Override
	public List<Score> getAllById(int sid) {
		List<Score> slist=new ArrayList<Score>();
		Student s=null;
		String sql="SELECT s1.`sid` , s1.`sname` , c.`coname` ,s2.`score` FROM student s1 ,score s2 ,course c WHERE"+
				" s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` AND s1.`sid`=?";
			ResultSet rs=bd.executeQuery(sql,sid);
			try {
				while(rs.next()){
					s=new Student(rs.getInt(1),rs.getString(2));
					Course c=new Course(rs.getString(3));
					Score sc=new Score(s,c,rs.getInt(4));
					slist.add(sc);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return slist;
	}
	
	
	@Override
	public List<Score> getBySid(int sid) {
		List<Score> slist=new ArrayList<Score>();
		Student s=null;
		String sql="SELECT   s1.`sid`, s1.`sname`, c.`coid`, c.`coname` ,c.`cimg` , c.`teacher` " +
					"FROM  student s1,score s2 , course c WHERE s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` AND s1.`sid`=?";
		ResultSet rs=bd.executeQuery(sql, sid);
		try {
			while(rs.next()){
				s=new Student(rs.getInt(1),rs.getString(2));
				Course c=new Course(rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6));
				Score sc=new Score(s,c);
				slist.add(sc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}

	
	
	
	@Override
	public List<Score> getAllByUname(String uname) {
		List<Score> slist=new ArrayList<Score>();
		Student s=null;
		String sql="SELECT s1.`sid` , s1.`sname` , c.`coname` ,s2.`score` FROM student s1 ,score s2 ,course c WHERE"+
				" s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` AND s1.`uname`=?";
			ResultSet rs=bd.executeQuery(sql,uname);
			try {
				while(rs.next()){
					s=new Student(rs.getInt(1),rs.getString(2));
					Course c=new Course(rs.getString(3));
					Score sc=new Score(s,c,rs.getInt(4));
					slist.add(sc);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return slist;
	}
	
	


	@Override
	public int countScore() {
		int re=-1;
		String sql="SELECT COUNT(*) FROM score s";
		ResultSet rs=bd.executeQuery(sql);
		try {
			if(rs.next()){
				re=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re;
	}
	


	@Override
	public List<Score> getByPage(int currentPage) {
		List<Score> slist=new ArrayList<Score>();
		String sql="SELECT   s1.`sid`, s1.`sname`,c.`coid`, c.`coname`  , s2.`score` "+
					"FROM  student s1,score s2 , course c WHERE s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` LIMIT ?,? ";
		ResultSet rs=bd.executeQuery(sql, currentPage,PAGESIZE);
		try {
			while(rs.next()){
				Student s=new Student(rs.getInt(1),rs.getString(2));
				Course c=new Course(rs.getInt(3),rs.getString(4));
				Score sc=new Score(s,c,rs.getInt(5));
				slist.add(sc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}
	

	@Override
	public int update(Score s) {
		int re=-1;
		String sql="UPDATE  score s SET score=?  WHERE sid =? AND coid=?";
		re=bd.executeUpdate(sql, s.getScore(),s.getSid() ,s.getCoid());
		return re;
	}


	@Override
	public Score getBySidCoid(int sid, int coid) {
		String sql="SELECT   s1.`sid` ,  s1.`sname`,  c.`coid`, c.`coname` , s2.`score`  FROM  student s1, score s2 , course c "+
					"WHERE s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid`  AND  s2.`sid`=? AND s2.`coid`=?";
		ResultSet rs=bd.executeQuery(sql, sid,coid);
		Score sc=null;
		try {
			if(rs.next()){
				Student s=new Student(rs.getInt(1),rs.getString(2));
				Course c=new Course(rs.getInt(3),rs.getString(4));
				sc=new Score(s,c,rs.getInt(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sc;
	}



	@Override
	public List<Score> getBySid2(int sid) {
		List<Score> slist=new ArrayList<Score>();
		Student s=null;
		String sql="SELECT  s1.`sid` ,  s1.`sname`,  c.`coid`, c.`coname` , s2.`score`"+
					"FROM  student s1 , score s2 , course c  WHERE s1.`sid`=s2.`sid` AND s2.`coid`=c.`coid` AND s2.`sid`=?";
		ResultSet rs=bd.executeQuery(sql, sid);
		try {
			while(rs.next()){
				s=new Student(rs.getInt(1),rs.getString(2));
				Course c=new Course(rs.getInt(3),rs.getString(4));
				Score sc=new Score(s,c,rs.getInt(5));
				slist.add(sc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return slist;
	}

	


	@Override
	public int delete(int sid, int coid) {
		int re=-1;
		String sql="DELETE  FROM  score   WHERE  sid=? AND coid=?";
		re=bd.executeUpdate(sql, sid, coid);
		return re;
	}


	@Override
	public int add(Score s) {
		int re=-1;
		String sql="INSERT INTO score(sid,coid) VALUES(?,?)";
		re=bd.executeUpdate(sql, s.getSid(),s.getCoid());
		return re;
	}

	public static void main(String[] args) {
		
	}
	
}

