package com.neusoft.service;

import com.neusoft.bean.PageScoreBean;
import com.neusoft.dao.ScoreDao;
import com.neusoft.impl.ScoreDaoImpl;

public class PageScoreService {
	public PageScoreBean getByPage(int currentPage){
		PageScoreBean p=new PageScoreBean();
		ScoreDao sd=new ScoreDaoImpl();
		int pageRow=sd.PAGESIZE;
		p.setPageRow(pageRow);
		int totalRecord=sd.countScore();
		p.setTotalRecord(totalRecord);
		p.setTotalPage(totalRecord%pageRow==0?totalRecord/pageRow:totalRecord/pageRow+1);
		p.setCurrentPage(currentPage);
		p.setSlist(sd.getByPage(currentPage));
		return p;
	}
}
