package com.neusoft.service;

import com.neusoft.bean.PageStudentBean;
import com.neusoft.dao.StudentDao;
import com.neusoft.impl.StudentDaoImpl;

public class pageStudentService {
	public PageStudentBean getByPage(int currentPage){
		PageStudentBean p=new PageStudentBean();
		StudentDao st=new StudentDaoImpl();
		int pageRow=st.PAGESIZE;
		p.setPageRow(pageRow);
		int totalRecord=st.countStu();
		p.setTotalRecord(totalRecord);
		p.setTotalPage(totalRecord%pageRow==0?totalRecord/pageRow:totalRecord/pageRow+1);
		p.setCurrentPage(currentPage);
		p.setSlist(st.getByPage(currentPage));
		return p;
	}
}
