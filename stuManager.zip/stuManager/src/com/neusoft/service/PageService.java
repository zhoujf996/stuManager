package com.neusoft.service;

import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.Course;
import com.neusoft.bean.PageBean;
import com.neusoft.dao.CourseDao;
import com.neusoft.impl.CourseDaoImpl;


public class PageService {
	public PageBean getByPage(int currentPage){
		PageBean p=new PageBean();
		CourseDao cd=new CourseDaoImpl();
		int pageRow=cd.PAGESIZE;
		p.setPageRow(pageRow);
		int totalRecord=cd.countCor();
		p.setTotalRecord(totalRecord);
		p.setTotalPage(totalRecord%pageRow==0?totalRecord/pageRow:totalRecord/pageRow+1);
		p.setCurrentPage(currentPage);
		p.setClist(cd.getByPage(currentPage));
		return p;
	}
}




