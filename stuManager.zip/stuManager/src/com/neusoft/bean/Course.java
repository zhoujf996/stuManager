package com.neusoft.bean;

public class Course {
	private int coid;
	private String coname;
	private String cimg;
	private String teacher;
	private Student student;
	private Score score;

	public Course() {
	
	}

	
	
	public Course(int coid, String coname, String cimg, String teacher,
			Student student, Score score) {
		super();
		this.coid = coid;
		this.coname = coname;
		this.cimg = cimg;
		this.teacher = teacher;
		this.student = student;
		this.score = score;
	}

	public Course(String cimg,int coid, String coname,  String teacher) {
		super();
		this.cimg = cimg;
		this.coid = coid;
		this.coname = coname;		
		this.teacher = teacher;
	}

	
	
	public Course(Student student,String cimg,int coid, String coname,  String teacher) {
		super();
		this.student = student;
		this.coid = coid;
		this.coname = coname;
		this.cimg = cimg;
		this.teacher = teacher;
	}


	public Course(String coname, String cimg, String teacher) {
		super();
		this.coname = coname;
		this.cimg = cimg;
		this.teacher = teacher;
	}

	public Course(String coname) {
		super();
		this.coname = coname;
		
	}



	public Course(int coid, String coname, String cimg, String teacher) {
		super();
		this.coid = coid;
		this.coname = coname;
		this.cimg = cimg;
		this.teacher = teacher;
	}

	public Course(int coid, String coname) {
		super();
		this.coid = coid;
		this.coname = coname;
		
	}

	public int getCoid() {
		return coid;
	}




	public void setCoid(int coid) {
		this.coid = coid;
	}




	public String getConame() {
		return coname;
	}




	public void setConame(String coname) {
		this.coname = coname;
	}




	public String getCimg() {
		return cimg;
	}




	public void setCimg(String cimg) {
		this.cimg = cimg;
	}




	public String getTeacher() {
		return teacher;
	}




	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}




	public Student getStudent() {
		return student;
	}



	public void setStudent(Student student) {
		this.student = student;
	}



	public Score getScore() {
		return score;
	}



	public void setScore(Score score) {
		this.score = score;
	}



	@Override
	public String toString() {
		return  coid +"\t"+coname +"\t"+teacher+"\t"+cimg;
	}
	
	
}
