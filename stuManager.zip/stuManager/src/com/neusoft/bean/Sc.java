package com.neusoft.bean;

public class Sc {
	private int sid;
	private int coid;
	private Student student;
	private Course course;
	
	public Sc() {
	}
	
	public Sc(Student student, Course course) {
		super();
		this.student = student;
		this.course = course;
	}

	public Sc(int sid, int coid, Student student, Course course) {
		super();
		this.sid = sid;
		this.coid = coid;
		this.student = student;
		this.course = course;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getCoid() {
		return coid;
	}

	public void setCoid(int coid) {
		this.coid = coid;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Course getCourse() {
		return course;
	}


	public void setCourse(Course course) {
		this.course = course;
	}


	@Override
	public String toString() {
		return sid+"\t"+coid+"\t"+student+"\t"+course;
	}

	
	
	
}
