package com.neusoft.bean;

public class Classes {
	private int cid;
	private String cname;
	private String college;
	
	public Classes(){
		
	}
	
	
	public Classes(int cid, String cname, String college) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.college = college;
	}
	
	public Classes(int cid, String cname) {
		super();
		this.cid = cid;
		this.cname = cname;
	}
	
	public Classes(String cname, String college) {
		this.cname = cname;
		this.college = college;
	}
	public Classes(String cname) {
		this.cname = cname;
	}
	
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}


	@Override
	public String toString() {
		return cid+"\t"+cname+"\t"+college;
	}
	
	
	
	
}
