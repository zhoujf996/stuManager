package com.neusoft.bean;

public class Admin {
	private int aid;
	private String uname;
	private String pwd;
	
	public Admin() {
		
	}
	
	public Admin(int aid, String uname, String pwd) {
		super();
		this.aid = aid;
		this.uname = uname;
		this.pwd = pwd;
	}
	

	public Admin(String uname, String pwd) {
		this.uname = uname;
		this.pwd = pwd;
	}

	public Admin(String uname) {
		this.uname = uname;
	}

	public Admin(int aid) {
		super();
		this.aid = aid;
		
	}
	

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return aid+"\t"+uname+"\t"+pwd;
	}
	
	
	
}
