package com.neusoft.bean;

public class Score {
	private int sid;
	private int coid;
	private int score;
	private Student student;
	private Course course;
	
	
	public Score() {
	
	}
	
	public Score(int sid, int coid, int score, Student student, Course course) {
		super();
		this.sid = sid;
		this.coid = coid;
		this.score = score;
		this.student = student;
		this.course = course;
	}


	
	public Score(int sid, int coid, int score) {
		super();
		this.sid = sid;
		this.coid = coid;
		this.score = score;
	}

	public Score(int sid, int coid) {
		super();
		this.sid = sid;
		this.coid = coid;
	}
	public Score(Student student, Course course,int score) {
		super();
		this.student = student;
		this.course = course;
		this.score=score;
	}
	
	public Score(Student student, Course course) {
		super();
		this.student = student;
		this.course = course;
		
	}


	public int getSid() {
		return sid;
	}


	public void setSid(int sid) {
		this.sid = sid;
	}


	public int getCoid() {
		return coid;
	}


	public void setCoid(int coid) {
		this.coid = coid;
	}


	public int getScore() {
		return score;
	}


	public void setScore(int score) {
		this.score = score;
	}

	


	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return sid+"\t"+coid+"\t"+score+"\t"+student+"\t"+course;
	}
	
	
	
}
