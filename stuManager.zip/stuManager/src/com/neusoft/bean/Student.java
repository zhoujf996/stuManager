package com.neusoft.bean;

public class Student {
	private int sid;
	private String sname;
	private String sex;
	private String address;
	private String uname;
	private String pwd;
	private String simg;
	private int cid;
	private Classes classes;
	
	public Student() {

	}
	
	
	public Student(int sid, String sname, String sex, String address,
			String uname, String pwd, String simg, int cid, Classes classes) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.simg = simg;
		this.cid = cid;
		this.classes = classes;
	}
	
	public Student(int sid, String sname, String sex, String address,
			String uname, String pwd, String simg, int cid) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.simg = simg;
		this.cid = cid;
	}
	
	public Student( String sname, String sex, String address,String uname, String pwd, String simg, int cid) {
		super();
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.simg = simg;
		this.cid = cid;
	}


	public Student(int sid, String sname, String sex, String address,
			String uname, String pwd, int cid, Classes classes) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.cid = cid;
		this.classes = classes;
	}
	

	
	public Student(int sid,String uname, String pwd) {
		super();
		this.sid = sid;
		this.uname = uname;
		this.pwd = pwd;
	}
	
	public Student(int sid, String sname, String sex, String address,
			String uname, String pwd, int cid) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.cid = cid;
	}
	
	public Student(String sname, String sex, String address,
			String uname, String pwd, int cid) {
		super();
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.uname = uname;
		this.pwd = pwd;
		this.cid = cid;
	}
	
	public Student(int sid, String sname, String sex, String address,
			 Classes classes) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sex = sex;
		this.address = address;
		this.classes = classes;
	}
	
	public Student(int sid, String sname) {
		this.sid = sid;
		this.sname = sname;
	}
	
	public Student(String uname, String pwd) {
		super();
		this.uname = uname;
		this.pwd = pwd;
	
	}
	
	public Student(String uname) {
		super();
		this.uname = uname;
	
	}
	public Student(int sid) {
		super();
		this.sid = sid;
	
	}
	
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	
	public String getSimg() {
		return simg;
	}


	public void setSimg(String simg) {
		this.simg = simg;
	}


	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	@Override
	public String toString() {
		return sid+"\t"+sname+"\t"+sex+"\t"+address+"\t"
				+uname+"\t"+pwd+"\t"+simg+"\t"+cid+"\t"+classes;
	}
	
	
	
	
}
