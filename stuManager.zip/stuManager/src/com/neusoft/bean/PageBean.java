package com.neusoft.bean;

import java.util.List;

public class PageBean {
	private List<Course> clist;//该页课程集合
	private int totalRecord;//总记录数
	private int totalPage;//总页数
	private int currentPage;//当前页
	private int pageRow;//每页显示的行数
	
	public PageBean() {
		
	}

	public PageBean(List<Course> clist, int totalRecord, int totalPage,
			int currentPage, int pageRow) {
		super();
		this.clist = clist;
		this.totalRecord = totalRecord;
		this.totalPage = totalPage;
		this.currentPage = currentPage;
		this.pageRow = pageRow;
	}

	public List<Course> getClist() {
		return clist;
	}

	public void setClist(List<Course> clist) {
		this.clist = clist;
	}

	public int getTotalRecord() {
		return totalRecord;
	}

	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageRow() {
		return pageRow;
	}

	public void setPageRow(int pageRow) {
		this.pageRow = pageRow;
	}
	
}
